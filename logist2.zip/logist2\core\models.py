from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.db.models import Sum, Q

# Базовый менеджер для управления обновлениями
class BaseManager(models.Manager):
    def update_related(self, instance):
        pass

# Справочники
class Line(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название линии")
    def __str__(self):
        return self.name

class Client(models.Model):
    name = models.CharField(max_length=100, verbose_name="Имя клиента")
    def __str__(self):
        return self.name

    @property
    def balance(self):
        """Вычисляет текущий баланс клиента (задолженность или переплата)."""
        invoices = self.invoice_set.all()
        total_due = invoices.aggregate(total=Sum('total_amount'))['total'] or 0
        total_paid = Payment.objects.filter(invoice__client=self).aggregate(total=Sum('amount'))['total'] or 0
        return total_paid - total_due

    def balance_details(self):
        """Детализация баланса по инвойсам."""
        invoices = self.invoice_set.all()
        details = []
        for invoice in invoices:
            paid = Payment.objects.filter(invoice=invoice).aggregate(total=Sum('amount'))['total'] or 0
            balance = paid - invoice.total_amount
            if balance != 0:
                details.append({
                    'invoice_number': invoice.number,
                    'balance': balance,
                    'status': 'Переплата' if balance > 0 else 'Задолженность'
                })
        return details

class Warehouse(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название склада")
    def __str__(self):
        return self.name

    @property
    def balance(self):
        """Вычисляет текущий баланс склада."""
        invoices = self.invoice_set.all()
        total_due = invoices.aggregate(total=Sum('total_amount'))['total'] or 0
        total_paid = Payment.objects.filter(invoice__warehouse=self).aggregate(total=Sum('amount'))['total'] or 0
        return total_paid - total_due

    def balance_details(self):
        """Детализация баланса по инвойсам."""
        invoices = self.invoice_set.all()
        details = []
        for invoice in invoices:
            paid = Payment.objects.filter(invoice=invoice).aggregate(total=Sum('amount'))['total'] or 0
            balance = paid - invoice.total_amount
            if balance != 0:
                details.append({
                    'invoice_number': invoice.number,
                    'balance': balance,
                    'status': 'Переплата' if balance > 0 else 'Задолженность'
                })
        return details

# Контейнеры
class ContainerManager(BaseManager):
    def update_related(self, instance):
        cars = instance.cars.all()
        if not cars:
            return
        ths_per_car = (instance.ths or 0) / cars.count()
        for car in cars:
            car.sync_with_container(instance, ths_per_car)
            car.save()

class Container(models.Model):
    STATUS_CHOICES = (
        ('FLOATING', 'Плывет'),
        ('IN_PORT', 'В порту'),
        ('UNLOADED', 'Разгружен'),
    )
    CUSTOMS_PROCEDURE_CHOICES = (
        ('TRANSIT', 'Транзит'),
        ('IMPORT', 'Импорт'),
        ('REEXPORT', 'Реэкспорт'),
        ('EXPORT', 'Экспорт'),
    )

    number = models.CharField(max_length=20, verbose_name="Номер контейнера", unique=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='FLOATING', verbose_name="Статус")
    line = models.ForeignKey('Line', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Морская линия")
    eta = models.DateField(null=True, blank=True, verbose_name="ETA")
    client = models.ForeignKey('Client', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Клиент")
    customs_procedure = models.CharField(max_length=20, choices=CUSTOMS_PROCEDURE_CHOICES, null=True, blank=True, verbose_name="Таможенная процедура")
    ths = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="THS", validators=[MinValueValidator(0)])
    sklad = models.DecimalField(max_digits=10, decimal_places=2, default=160, verbose_name="SKLAD", validators=[MinValueValidator(0)])
    dekl = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="DEKL", validators=[MinValueValidator(0)])
    proft = models.DecimalField(max_digits=10, decimal_places=2, default=20, verbose_name="PROFT", validators=[MinValueValidator(0)])
    warehouse = models.ForeignKey('Warehouse', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Склад")
    unload_date = models.DateField(null=True, blank=True, verbose_name="Дата разгрузки")
    free_days = models.PositiveIntegerField(default=0, verbose_name="Бесплатные дни")
    days = models.PositiveIntegerField(default=0, verbose_name="DAYS")
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=5, verbose_name="Ставка", validators=[MinValueValidator(0)])
    storage_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Складирование")

    objects = ContainerManager()

    def update_days_and_storage(self):
        if self.status == 'UNLOADED' and self.unload_date:
            total_days = (timezone.now().date() - self.unload_date).days + 1
            self.days = max(0, total_days - self.free_days)
            self.storage_cost = self.days * (self.rate or 0)
        else:
            self.days = 0
            self.storage_cost = 0

    def sync_cars(self):
        self.update_days_and_storage()
        Container.objects.update_related(self)

    def save(self, *args, **kwargs):
        if self.status == 'UNLOADED' and (not self.warehouse or not self.unload_date):
            raise ValueError("Для статуса 'Разгружен' обязательны поля 'Склад' и 'Дата разгрузки'")
        super().save(*args, **kwargs)
        self.sync_cars()
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "updates",
            {
                "type": "data_update",
                "data": {"model": "Container", "id": self.id, "status": self.status}
            }
        )

    def __str__(self):
        return self.number

# Автомобили
class CarManager(BaseManager):
    def update_related(self, instance):
        for invoice in instance.invoice_set.all():
            invoice.update_total_amount()
            invoice.save()

class Car(models.Model):
    year = models.PositiveIntegerField(verbose_name="Год выпуска")
    brand = models.CharField(max_length=50, verbose_name="Марка")
    vin = models.CharField(max_length=17, unique=True, verbose_name="VIN")
    client = models.ForeignKey('Client', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Клиент")
    status = models.CharField(max_length=20, choices=Container.STATUS_CHOICES, verbose_name="Статус")
    warehouse = models.ForeignKey('Warehouse', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Склад")
    unload_date = models.DateField(null=True, blank=True, verbose_name="Дата разгрузки")
    container = models.ForeignKey('Container', on_delete=models.CASCADE, related_name="cars", verbose_name="Контейнер")
    total_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Итоговая цена")
    ths = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="THS", validators=[MinValueValidator(0)])
    sklad = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="SKLAD", validators=[MinValueValidator(0)])
    dekl = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="DEKL", validators=[MinValueValidator(0)])
    proft = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="PROFT", validators=[MinValueValidator(0)])
    free_days = models.PositiveIntegerField(default=0, verbose_name="Бесплатные дни")
    days = models.PositiveIntegerField(default=0, verbose_name="DAYS")
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=5, verbose_name="Ставка", validators=[MinValueValidator(0)])
    storage_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Складирование")

    objects = CarManager()

    def calculate_total_price(self):
        ths = self.ths or 0
        sklad = self.sklad or 0
        dekl = self.dekl or 0
        proft = self.proft or 0
        return ths + sklad + dekl + proft + self.storage_cost

    def update_days_and_storage(self):
        if self.unload_date:
            total_days = (timezone.now().date() - self.unload_date).days + 1
            self.days = max(0, total_days - self.free_days)
            self.storage_cost = self.days * (self.rate or 0)
        else:
            self.days = 0
            self.storage_cost = 0
        self.total_price = self.calculate_total_price()

    def sync_with_container(self, container, ths_per_car):
        self.status = container.status
        self.warehouse = container.warehouse
        self.unload_date = container.unload_date
        self.ths = ths_per_car
        self.sklad = container.sklad
        self.dekl = container.dekl
        self.proft = container.proft
        self.free_days = container.free_days
        self.rate = container.rate
        self.update_days_and_storage()
        self.total_price = self.calculate_total_price()

    def save(self, *args, **kwargs):
        if self.container and not self.client:
            self.client = self.container.client
        self.update_days_and_storage()
        super().save(*args, **kwargs)
        Car.objects.update_related(self)
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "updates",
            {
                "type": "data_update",
                "data": {"model": "Car", "id": self.id, "status": self.status}
            }
        )

    def __str__(self):
        return f"{self.brand} ({self.vin})"

# Инвойсы
class Invoice(models.Model):
    number = models.CharField(max_length=20, unique=True, verbose_name="Номер инвойса")
    client = models.ForeignKey('Client', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Клиент")
    warehouse = models.ForeignKey('Warehouse', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Склад")
    cars = models.ManyToManyField(Car, verbose_name="Автомобили")
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Сумма")
    issue_date = models.DateField(auto_now_add=True, verbose_name="Дата выпуска")
    paid = models.BooleanField(default=False, verbose_name="Оплачен")
    is_outgoing = models.BooleanField(default=False, verbose_name="Нужно оплатить")

    def update_total_amount(self):
        try:
            total = 0.0
            for car in self.cars.all():
                if not self.is_outgoing:
                    price = car.total_price if car.total_price is not None else 0
                    total += float(price)
                else:
                    cost = car.storage_cost if car.storage_cost is not None else 0
                    total += float(cost)
            self.total_amount = total
            print(f"Updated total_amount in model: {self.total_amount}")
        except Exception as e:
            print(f"Error calculating total_amount: {e}")
            self.total_amount = 0.00

    @property
    def paid_amount(self):
        """Сумма всех платежей по инвойсу."""
        return Payment.objects.filter(invoice=self).aggregate(total=Sum('amount'))['total'] or 0

    @property
    def balance(self):
        """Остаток по инвойсу (переплата или недоплата)."""
        return self.paid_amount - self.total_amount

    def save(self, *args, **kwargs):
        self.update_total_amount()
        super().save(*args, **kwargs)
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "updates",
            {
                "type": "data_update",
                "data": {"model": "Invoice", "id": self.id, "total_amount": str(self.total_amount)}
            }
        )

    def __str__(self):
        direction = "Нужно оплатить" if self.is_outgoing else "Ждём оплату"
        return f"{self.number} ({direction})"

# Платежи
class Payment(models.Model):
    TYPE_CHOICES = (
        ('CASH', 'Наличные'),
        ('CARD', 'Безналичные'),
    )
    invoice = models.ForeignKey(Invoice, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Инвойс")
    amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Сумма")
    payment_type = models.CharField(max_length=20, choices=TYPE_CHOICES, verbose_name="Тип платежа")
    date = models.DateField(auto_now_add=True, verbose_name="Дата")
    payer = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Плательщик")
    recipient = models.CharField(max_length=100, verbose_name="Получатель")

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.invoice:
            # Обновляем статус инвойса
            invoice = self.invoice
            invoice.paid = invoice.paid_amount >= invoice.total_amount
            invoice.save()
            # Уведомляем через WebSocket
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                "updates",
                {
                    "type": "data_update",
                    "data": {"model": "Payment", "id": self.id, "invoice_id": invoice.id if invoice else None}
                }
            )

    def __str__(self):
        return f"{self.amount} ({self.payment_type})"

# Декларации
class Declaration(models.Model):
    number = models.CharField(max_length=20, unique=True, verbose_name="Номер декларации")
    container = models.ForeignKey(Container, on_delete=models.CASCADE, verbose_name="Контейнер")
    customs_procedure = models.CharField(max_length=20, choices=Container.CUSTOMS_PROCEDURE_CHOICES, verbose_name="Таможенная процедура")
    date = models.DateField(verbose_name="Дата оформления")

    def __str__(self):
        return self.number

# Бухгалтерия
class Accounting(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, verbose_name="Инвойс")
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, null=True, blank=True, verbose_name="Платеж")
    sync_status = models.CharField(max_length=20, default="PENDING", verbose_name="Статус синхронизации")
    sync_date = models.DateTimeField(null=True, blank=True, verbose_name="Дата синхронизации")

    def __str__(self):
        return f"{self.invoice} - {self.sync_status}"