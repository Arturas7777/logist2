from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_GET
from django.utils import timezone
from django.template.loader import render_to_string
from django.contrib.auth.decorators import login_required
from .models import Car, Invoice, Container, Payment
from django.db.models import Q


def car_list_api(request):
    client_id = request.GET.get('client_id')
    search_query = request.GET.get('search', '').strip().lower()
    print(f"API called with GET: {request.GET}")
    print(f"Extracted client_id: {client_id}, search: '{search_query}'")

    if client_id and client_id != 'undefined' and client_id.isdigit():
        all_cars = Car.objects.filter(client_id=client_id)
        print(f"All cars for client {client_id}: {all_cars.count()}")
        for car in all_cars:
            print(f"All cars - Car {car.id}: VIN={car.vin}, Brand={car.brand}, Year={car.year}, Status={car.status}")

        if search_query:
            all_cars = all_cars.filter(
                Q(vin__icontains=search_query) |
                Q(brand__icontains=search_query) |
                Q(year__icontains=search_query)
            )
            print(f"Filtered cars with search '{search_query}': {all_cars.count()}")
            for car in all_cars:
                print(
                    f"Filtered car: {car.id} - VIN: {car.vin}, Brand: {car.brand}, Year: {car.year}, Status: {car.status}")

        unloaded_cars = all_cars.filter(status='UNLOADED')
        print(f"Unloaded cars for client {client_id}: {unloaded_cars.count()}")
        for car in unloaded_cars:
            print(f"Unloaded car {car.id}: {car} - Status: {car.status}")

        html = render_to_string('admin/car_options.html', {'cars': unloaded_cars}, request=request)
        print(f"Returning HTML: {html}")
        return HttpResponse(html, content_type='text/html')
    print("No valid client_id, returning empty response")
    return HttpResponse('<span>No cars found</span>', content_type='text/html')


@require_GET
def get_invoice_total(request):
    car_ids = request.GET.get('car_ids', '').split(',')
    car_ids = [int(cid) for cid in car_ids if cid.strip().isdigit()]
    print(f"Received car_ids in get_invoice_total: {car_ids}")

    if not car_ids:
        print("No valid car IDs provided, returning 0.00")
        return JsonResponse({'total_amount': '0.00'})

    try:
        cars = Car.objects.filter(id__in=car_ids)
        if not cars.exists():
            print(f"No cars found for IDs: {car_ids}")
            return JsonResponse({'total_amount': '0.00', 'error': 'No cars found for the provided IDs'})
        print(f"Cars found: {list(cars)}")
        for car in cars:
            print(f"Car {car.id}: total_price={car.total_price}, storage_cost={car.storage_cost}")
    except Exception as e:
        print(f"Error querying cars: {e}")
        return JsonResponse({'total_amount': '0.00', 'error': f"Error querying cars: {e}"}, status=500)

    timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
    invoice = Invoice(number=f"temp_{timestamp}", issue_date=timezone.now().date())
    try:
        invoice.save()
        print(f"Temporary invoice saved with number: {invoice.number}")
    except Exception as e:
        print(f"Error saving temporary invoice: {e}")
        return JsonResponse({'total_amount': '0.00', 'error': f"Failed to save temporary invoice: {e}"}, status=500)

    try:
        invoice.cars.set(cars)
        print(f"Cars set to invoice: {list(invoice.cars.all())}")
    except Exception as e:
        print(f"Error setting cars: {e}")
        invoice.delete()
        return JsonResponse({'total_amount': '0.00', 'error': f"Failed to set cars: {e}"}, status=500)

    try:
        invoice.update_total_amount()
        print(f"Calculated total_amount: {invoice.total_amount}")
        result = {'total_amount': str(invoice.total_amount or '0.00')}
    except Exception as e:
        print(f"Error in update_total_amount: {e}")
        for car in invoice.cars.all():
            print(
                f"Car {car.id}: total_price={car.total_price}, storage_cost={car.storage_cost}, is_outgoing={invoice.is_outgoing}")
        result = {'total_amount': '0.00', 'error': str(e)}
    finally:
        try:
            invoice.delete()
            print("Temporary invoice deleted")
        except Exception as e:
            print(f"Error deleting temporary invoice: {e}")

    return JsonResponse(result)


@require_GET
def get_container_data(request, container_id):
    try:
        container = Container.objects.get(id=container_id)
        data = {
            'free_days': container.free_days,
            'storage_cost': str(container.storage_cost),
            'status': container.status,
        }
        return JsonResponse(data)
    except Container.DoesNotExist:
        return JsonResponse({'error': 'Container not found'}, status=404)

@login_required
def register_payment(request):
    if request.method == 'POST':
        invoice_id = request.POST.get('invoice_id')
        amount = float(request.POST.get('amount', 0))
        payment_type = request.POST.get('payment_type')
        description = request.POST.get('description', '')
        payer_id = request.POST.get('payer_id')
        recipient = request.POST.get('recipient', '')

        try:
            invoice = Invoice.objects.get(id=invoice_id) if invoice_id else None
            payer = Client.objects.get(id=payer_id) if payer_id else None
            payment = Payment(
                invoice=invoice,
                amount=amount,
                payment_type=payment_type,
                description=description,
                payer=payer,
                recipient=recipient
            )
            payment.save()
            return JsonResponse({'status': 'success', 'message': f'Payment of {amount} registered'})
        except (Invoice.DoesNotExist, Client.DoesNotExist) as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=400)