from django.contrib import admin
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import Client, Warehouse, Car, Invoice, Payment, Container, Declaration, Accounting, Line

class CarInline(admin.TabularInline):
    model = Car
    extra = 1
    can_delete = True
    fields = ('year', 'brand', 'vin', 'client', 'status', 'warehouse', 'unload_date', 'storage_cost', 'ths', 'sklad', 'dekl', 'proft', 'total_price')

    def get_formset(self, request, obj=None, **kwargs):
        formset = super().get_formset(request, obj, **kwargs)
        formset.form.base_fields['storage_cost'].label = 'Складир.'
        return formset

@admin.register(Container)
class ContainerAdmin(admin.ModelAdmin):
    change_form_template = 'admin/core/container/change_form.html'
    list_display = ('number', 'status', 'line', 'eta', 'client', 'warehouse', 'unload_date')
    list_filter = ('status', 'line', 'client')
    search_fields = ('number',)
    inlines = [CarInline]
    fieldsets = (
        (None, {
            'fields': (
                ('number', 'status', 'eta'),
                ('line'),
                ('client'),
                ('customs_procedure'),
                ('warehouse'),
                ('unload_date'),
                ('ths', 'sklad'),
                ('dekl', 'proft'),
                ('free_days',),
                ('days',),
                ('rate',),
                ('storage_cost',),
            )
        }),
    )

    class Media:
        css = {
            'all': ('css/logist2_custom_admin.css',)
        }
        js = ('js/logist2_htmx.js',)

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        obj.refresh_from_db()
        obj.update_days_and_storage()
        obj.save(update_fields=['days', 'storage_cost'])

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['free_days'].label = 'Бесплатные дни'
        form.base_fields['days'].label = 'Платные дни'
        form.base_fields['storage_cost'].label = 'Складирование'
        return form

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ('vin', 'brand', 'year', 'client', 'status', 'warehouse', 'total_price', 'ths', 'sklad', 'dekl', 'proft', 'free_days', 'days', 'rate', 'storage_cost')
    list_filter = ('status', 'warehouse')
    search_fields = ('vin', 'brand')
    fieldsets = (
        (None, {
            'fields': (
                ('year', 'brand', 'vin'),
                ('client', 'status'),
                ('warehouse', 'unload_date'),
                'container',
                ('ths', 'sklad'),
                ('dekl', 'proft'),
                ('free_days', 'days', 'rate'),
                ('storage_cost',),
                'total_price',
            )
        }),
    )

    class Media:
        css = {
            'all': ('css/logist2_custom_admin.css',)
        }

@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    change_form_template = 'admin/invoice_change.html'
    list_display = ('number', 'display_client', 'warehouse', 'total_amount', 'issue_date', 'paid', 'is_outgoing', 'balance_display')
    list_filter = ('paid', 'is_outgoing', 'client', 'warehouse')
    search_fields = ('number',)
    fieldsets = (
        (None, {
            'fields': (
                ('number', 'client', 'warehouse'),
                ('paid', 'is_outgoing'),
                'total_amount',
            )
        }),
    )
    readonly_fields = ('total_amount',)
    actions = ['register_payment_link']

    class Media:
        css = {
            'all': ('css/logist2_custom_admin.css',)
        }
        js = ('js/logist2_htmx.js', 'js/logist2_invoice_admin.js')

    def display_client(self, obj):
        return obj.client.name if obj.client else "-"
    display_client.short_description = "Клиент"

    def balance_display(self, obj):
        balance = obj.balance
        status = 'Переплата' if balance > 0 else 'Недоплата' if balance < 0 else 'Оплачено полностью'
        return f"{balance:.2f} ({status})"
    balance_display.short_description = 'Баланс'

    def register_payment_link(self, request, queryset):
        # Передаем все инвойсы и клиентов в форму регистрации платежа
        invoices = Invoice.objects.all()
        clients = Client.objects.all()
        return render(request, 'admin/register_payment.html', {'invoices': invoices, 'clients': clients})
    register_payment_link.short_description = "Зарегистрировать платеж"

    def save_model(self, request, obj, form, change):
        print(f"Saving invoice - Number: {obj.number}, Paid: {obj.paid}, Is Outgoing: {obj.is_outgoing}")
        print(f"Full POST data: {request.POST}")
        client_id = request.POST.get('client')
        print(f"Client ID from form: {client_id}")
        if client_id and client_id.isdigit() and client_id != '':
            obj.client_id = int(client_id)
            print(f"Set client_id: {obj.client_id}")
        else:
            obj.client = None
            print("Client set to None. Checking form fields:", request.POST.keys())

        super().save_model(request, obj, form, change)
        print(f"After save - Client: {obj.client}, ID: {obj.id}")

        car_ids_str = request.POST.get('cars', '')
        print(f"Raw car_ids from form: '{car_ids_str}'")
        if car_ids_str:
            car_ids = [int(cid) for cid in car_ids_str.split(',') if cid.strip().isdigit()]
            print(f"Parsed car_ids: {car_ids}")
            if car_ids:
                obj.cars.set(car_ids)
                print(f"Set cars: {car_ids}")
            else:
                print("No valid car IDs found, leaving cars unchanged")
        else:
            print("No car IDs provided in form, leaving cars unchanged")

        obj.update_total_amount()
        obj.save(update_fields=['total_amount'])
        print(f"Updated Total Amount: {obj.total_amount}")
        print(f"After final save - Cars in DB: {list(obj.cars.all())}")

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if obj:
            print(f"Object: {obj}, Client: {obj.client}, Cars: {obj.cars.all()}")
            form.base_fields['number'].initial = obj.number
            form.base_fields['warehouse'].initial = obj.warehouse
            form.base_fields['paid'].initial = obj.paid
            form.base_fields['is_outgoing'].initial = obj.is_outgoing
            form.base_fields['client'].initial = obj.client_id
        return form

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('amount', 'payment_type', 'date', 'payer', 'recipient', 'invoice')

# Регистрация остальных моделей без дублирования
admin.site.register(Client)
admin.site.register(Warehouse)
admin.site.register(Declaration)
admin.site.register(Accounting)
admin.site.register(Line)