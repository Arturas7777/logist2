from django.urls import path
from . import views

urlpatterns = [
    path('get_container_data/<int:pk>/', views.get_container_data, name='get_container_data'),
    # Добавь другие URL-паттерны, если они есть в твоём проекте
]
